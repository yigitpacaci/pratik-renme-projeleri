package oop5;

public class idman {

	private int burpee_sayisi;
	private int pushup_sayisi;
	private int situp_sayisi;
	private int squat_sayisi;
	
	
	public idman(int burpee_sayisi, int pushup_sayisi, int situp_sayisi, int squat_sayisi) {
		super();
		this.burpee_sayisi = burpee_sayisi;
		this.pushup_sayisi = pushup_sayisi;
		this.situp_sayisi = situp_sayisi;
		this.squat_sayisi = squat_sayisi;
	}


	public int getBurpee_sayisi() {
		return burpee_sayisi;
	}


	public void setBurpee_sayisi(int burpee_sayisi) {
		this.burpee_sayisi = burpee_sayisi;
	}


	public int getPushup_sayisi() {
		return pushup_sayisi;
	}


	public void setPushup_sayisi(int pushup_sayisi) {
		this.pushup_sayisi = pushup_sayisi;
	}


	public int getSitup_sayisi() {
		return situp_sayisi;
	}


	public void setSitup_sayisi(int situp_sayisi) {
		this.situp_sayisi = situp_sayisi;
	}


	public int getSquat_sayisi() {
		return squat_sayisi;
	}


	public void setSquat_sayisi(int squat_sayisi) {
		this.squat_sayisi = squat_sayisi;
	}
	
	public void haraketyap(String HaraketTuru,int sayi) {
		
		if	(HaraketTuru.equals("burpee")) {
			burpeeyap(sayi);
			
		}
		
		else if(HaraketTuru.equals("pushup")) {
			pushupyap(sayi);
			
		}
		else if(HaraketTuru.equals("situp")) {
			situpyap(sayi);
			
		}
		else if(HaraketTuru.equals("squat")) {
			squatyap(sayi);
			
		}
		else {
			System.out.println("geçersiz haraket ");
			
		}
	}
	public void burpeeyap(int sayi) {
		if (burpee_sayisi==0) {
			System.out.println("yapıcak bişi kalmadı");
		}
		if (burpee_sayisi-sayi<0) {
			System.out.println("hedeflediğin burpee sayisini geçtin tebrikler");
			burpee_sayisi=0;
			System.out.println("kalan burpee "+burpee_sayisi);
			
		}
		else {
			burpee_sayisi-=sayi;
			System.out.println("kalan burpee sayisi :" +burpee_sayisi);
		}
		
	}
	public void pushupyap(int sayi) {
		if (pushup_sayisi==0) {
			System.out.println("yapıcak bişi kalmadı");
		}
		if (pushup_sayisi-sayi<0) {
			System.out.println("hedeflediğin pushup sayisini geçtin tebrikler");
			pushup_sayisi=0;
			System.out.println("kalan pushup "+pushup_sayisi);
			
		}
		else {
			pushup_sayisi-=sayi;
			System.out.println("kalan pushup sayisi :" +pushup_sayisi);
		}
		
	}
	public void situpyap(int sayi) {
		if (situp_sayisi==0) {
			System.out.println("yapıcak bişi kalmadı");
		}
		if (situp_sayisi-sayi<0) {
			System.out.println("hedeflediğin situp sayisini geçtin tebrikler");
			situp_sayisi=0;
			System.out.println("kalan situp "+situp_sayisi);
			
		}
		else {
			situp_sayisi-=sayi;
			System.out.println("kalan situp sayisi :" +situp_sayisi);
		}
		
	}
	public void squatyap(int sayi) {
		if (squat_sayisi==0) {
			System.out.println("yapıcak bişi kalmadı");
		}
		if (squat_sayisi-sayi<0) {
			System.out.println("hedeflediğin squat sayisini geçtin tebrikler");
			squat_sayisi=0;
			System.out.println("kalan squat "+squat_sayisi);
			
		}
		else {
			squat_sayisi-=sayi;
			System.out.println("kalan squat sayisi :" +squat_sayisi);
		}
		
	}
	
	public boolean idmanbittimi() {
		
		return (burpee_sayisi ==0)&&(pushup_sayisi==0)&&(situp_sayisi==0)&&(squat_sayisi==0);
		
	}
	

}
