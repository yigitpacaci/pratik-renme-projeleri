package oop2;

import oop2.araba;

public class test {
	public static void main(String[]args) {
		araba araba1= new araba();
	
		/*araba1.setmodel("bmw");
		System.out.println("arabanın modeli : "+ araba1.getmodel());
		
		araba1.setkapılar(-5);*/
		
		araba araba2;
		
		
	}
}
