package oop1;

public class araba {
	
	public String renk;
	public String motor;
	public String model;
	public int kapılar;
	public int tekerlekler;
}
