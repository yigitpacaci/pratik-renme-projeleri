package oop5;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
	Scanner scanner= new Scanner(System.in);
	
	System.out.println("idman programına hoşgeldin");
	
	String idmanlar="geçerli haraketler\n"
			 +"burpee\n"
			+"pushup\n"
			 +"situp\n"
			+"squat\n";
	System.out.println(idmanlar);
	System.out.println("bir idman oluşturun");
	
	System.out.println("burpee sayisi:");
	int burpee =scanner.nextInt();
	System.out.println("pushup sayisi:");
	int pushup =scanner.nextInt();
	System.out.println("situp sayisi:");
	int situp =scanner.nextInt();
	System.out.println("squat sayisi:");
	int squat =scanner.nextInt();
	scanner.nextLine();
	idman idman =new idman(burpee,pushup,situp,squat);
	System.out.println("idmanınız başlıyor");
	
	while(idman.idmanbittimi()==false) {
		System.out.println("haraket türü : (burpee,pushup,situp,squat)");
		String tur=scanner.nextLine();
		System.out.println("bu haraketten kaç tane yapıcksınız");
		int sayi=scanner.nextInt();
		scanner.nextLine();
		idman.haraketyap(tur, sayi);
	}
	

	}

}
