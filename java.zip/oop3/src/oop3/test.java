package oop3;

public class test {
	
	public static void main(String[]args) {
		
		
		
	
		//account account1 = new account("yiğit","yigitpacaci@gmail.com","5313014988");
		//account account2=account1;
		
		/*account account2 = new account("1234","7377282882","WEUHFIWE",1000,"VELİ");
		account2.parayatir(500);
		account2.paracekme(10000);
		System.out.println("isim"+account2.getIsim());*/
		//System.out.println("email"+account1.getEmail());
		//account account2 =new account("yiğit","yigitpacaci@gmail.com","5313014988");
		//System.out.println("isim"+account2.getEmail());
		//System.out.println("bakiye"+account2.getbakiye());
		
		
		
		
		
		
		
		
		
		/*account1.sethesapno("1234");
		account1.setbakiye(1000);
		account1.setIsim("yiğit");
		account1.setEmail("falan");
		account1.setTelefonno("5313014988");
		
		System.out.println("isim  " +  account1.getIsim());*/
		
		
		
		
		
	}

}
