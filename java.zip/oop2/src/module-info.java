/**
 * 
 */
/**
 * 
 */
module oop2 {
}