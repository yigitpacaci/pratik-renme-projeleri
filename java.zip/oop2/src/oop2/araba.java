package oop2;

public class araba {
	private String renk;
	private String motor;
	private String model;
	private int kapılar;
	private int tekerlekler;
	
	
	public void setmodel(String model) {
		this.model=model;
		
	}
	
	public String getmodel() {
		
		return model;
		
	}

	public String getRenk() {
		return renk;
	}

	public void setRenk(String renk) {
		this.renk = renk;
	}

	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}

	public int getKapılar() {
		return kapılar;
	}

	public void setkapılar(int kapılar) {
		if(kapılar<0) {
			System.out.println("öyle - olamaz");
		}
		else {
			this.kapılar=kapılar;
			
		}
	}

	public int getTekerlekler() {
		return tekerlekler;
	}

	public void setTekerlekler(int tekerlekler) {
		this.tekerlekler = tekerlekler;
	}
}
