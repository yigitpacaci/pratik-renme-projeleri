package oop3;

public class account {
	private String hesapno;
	private String Telefonno;
	private String Email;
	private double bakiye;
	private String Isim;
	
	public account() {
		//System.out.println("kendi yazdığımız constructor");
		/*this.hesapno = "bilgi yok";
		this.Telefonno = "bilgi yok";
		this.Email = "bilgi yok";
		this.bakiye = 0.0;
		this.Isim = "bilgi yok";*/
		
		this("bilgi yok","bilgi yok","bilgi yok",0.0,"bilgi yok");

		
		
	}
	public account(String Isim,String Email,String Telefonno) {
		/*this.Isim = Isim;
		this.Email = Email;
		this.Telefonno = Telefonno;
		this.bakiye=0.0;
		this.hesapno="bilgi yok";*/
		
		this("bilgi yok",Telefonno,Email,0.0,Isim);
		
		 
	}
	
	public account(String hesapno,String Telefonno,String Email,double bakiye,String Isim) {
		this.hesapno = hesapno;
		this.Telefonno = Telefonno;
		this.Email = Email;
		this.bakiye = bakiye;
		this.Isim = Isim;
		
		
	}
	
	
	
	
	
	public void parayatir(double miktar) {
		
		bakiye+=miktar;
		System.out.println("yeni bakiye"+bakiye);
	}
	public void paracekme(double miktar) {
		if(miktar>1500) {
			System.out.println("para çekemezsin");
			if(bakiye-miktar<0) {
				System.out.println("yetersiz bakiye"+bakiye);	
			}
			else {
				bakiye-=miktar;
				System.out.println("yeni bakiye"+bakiye);
				
			}
			
		}
	}
				
	
	
	
	
	public String gethesapno() {
		return hesapno;
	}
	public void sethesapno(String hesapno) {
		this.hesapno = hesapno;
	}
	public String getTelefonno() {
		return Telefonno;
	}
	public void setTelefonno(String Telefonno) {
		this.Telefonno = Telefonno;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email) {
		this.Email = Email;
	}
	public double getbakiye() {
		return bakiye;
	}
	public void setbakiye(double bakiye) {
		this.bakiye = bakiye;
	}
	public String getIsim() {
		return Isim;
	}
	public void setIsim(String isim) {
		this.Isim = isim;
	}
	
}
