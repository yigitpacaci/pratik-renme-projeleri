package oop1;

public class test {
public static void main(String[]args) {
	araba araba1= new araba();
	araba1.renk="yeşil";
	araba1.model="dacia";
	araba1.kapılar=9;
	araba1.tekerlekler=4;
	araba1.motor="16v";
	
	System.out.println(araba1.motor);
	System.out.println(araba1.renk);
	
}
}
